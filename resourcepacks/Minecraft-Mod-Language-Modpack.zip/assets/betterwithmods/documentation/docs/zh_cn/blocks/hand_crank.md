![手推曲柄](block:betterwithmods:hand_crank)

手推曲柄是最初级的机械能源，用于为任何不需要*持续*充能的机械充能.
比如说[磨石](millstone.md)就是你在生存中第一个需要充能的制作装置，没有它你就无法制作风车